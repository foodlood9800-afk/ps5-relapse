package com.example.prosperomgr;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.content.Context;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceError;
import android.app.AlertDialog;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import android.text.InputType;
import android.view.Gravity;

public class MainActivity extends Activity {
    private WebView webView;
    private EditText ipInput, portInput;
    private LinearLayout connectScreen;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        showConnectScreen();
    }

    private int dp(int v) { return (int)(v * getResources().getDisplayMetrics().density + 0.5f); }

    private void showConnectScreen() {
        LinearLayout root = new LinearLayout(this);
        connectScreen = root;
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(20), dp(28), dp(20), dp(20));
        root.setBackgroundColor(Color.WHITE);

        TextView title = new TextView(this);
        title.setText("ProsperoMgr Remote");
        title.setTextSize(24);
        title.setTextColor(Color.rgb(25, 45, 80));
        title.setGravity(Gravity.CENTER_VERTICAL);
        root.addView(title, new LinearLayout.LayoutParams(-1, dp(54)));

        TextView info = new TextView(this);
        info.setText("أدخل عنوان IP للـ PS5. لازم ProsperoMgr.elf يكون شغّال على الجهاز والموبايل والـPS5 على نفس الشبكة.");
        info.setTextSize(16);
        info.setTextColor(Color.DKGRAY);
        info.setPadding(0, dp(8), 0, dp(18));
        root.addView(info);

        ipInput = new EditText(this);
        ipInput.setSingleLine(true);
        ipInput.setHint("مثال: 192.168.1.100");
        ipInput.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_URI);
        root.addView(ipInput, new LinearLayout.LayoutParams(-1, dp(54)));

        portInput = new EditText(this);
        portInput.setSingleLine(true);
        portInput.setHint("Port (افتراضي 7070)");
        portInput.setText("7070");
        portInput.setInputType(InputType.TYPE_CLASS_NUMBER);
        LinearLayout.LayoutParams pp = new LinearLayout.LayoutParams(-1, dp(54));
        pp.topMargin = dp(8);
        root.addView(portInput, pp);

        Button connect = new Button(this);
        connect.setText("اتصال");
        LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(-1, dp(52));
        bp.topMargin = dp(16);
        root.addView(connect, bp);

        TextView note = new TextView(this);
        note.setText("هذا تطبيق واجهة WebView غير رسمي، وليس تطبيقاً أصلياً من مطوّر ProsperoMgr.");
        note.setTextSize(13);
        note.setTextColor(Color.GRAY);
        note.setPadding(0, dp(20), 0, 0);
        root.addView(note);
        connect.setOnClickListener(v -> openDashboard());
        setContentView(root);
    }

    private void openDashboard() {
        String host = ipInput.getText().toString().trim();
        String port = portInput.getText().toString().trim();
        if (host.isEmpty()) {
            Toast.makeText(this, "أدخل IP الخاص بالـPS5 أولاً", Toast.LENGTH_LONG).show();
            return;
        }
        if (port.isEmpty()) port = "7070";
        if (!host.matches("[A-Za-z0-9.-]+")) {
            Toast.makeText(this, "عنوان IP أو اسم المضيف غير صالح", Toast.LENGTH_LONG).show();
            return;
        }
        int portNumber;
        try {
            portNumber = Integer.parseInt(port);
            if (portNumber < 1 || portNumber > 65535) throw new NumberFormatException();
        } catch (NumberFormatException e) {
            Toast.makeText(this, "المنفذ لازم يكون بين 1 و65535", Toast.LENGTH_LONG).show();
            return;
        }
        String url = "http://" + host + ":" + portNumber + "/";
        webView = new WebView(this);
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(false);
        settings.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        webView.setWebViewClient(new WebViewClient() {
            @Override
            public void onReceivedError(WebView view, WebResourceRequest request, WebResourceError error) {
                super.onReceivedError(view, request, error);
                if (request.isForMainFrame()) showConnectionError(url);
            }
        });
        webView.setWebChromeClient(new WebChromeClient());
        setContentView(webView);
        webView.loadUrl(url);
    }

    private void showConnectionError(String url) {
        new AlertDialog.Builder(this)
            .setTitle("تعذّر الاتصال بالـ PS5")
            .setMessage("تأكد من التالي:\n\n• الهاتف والـ PS5 على نفس شبكة Wi-Fi.\n• عنوان IP والمنفذ صحيحان.\n• ProsperoMgr.elf يعمل على PS5.\n• المنفذ الافتراضي هو 7070.\n\nالعنوان: " + url)
            .setPositiveButton("إعادة المحاولة", (dialog, which) -> webView.loadUrl(url))
            .setNegativeButton("رجوع", (dialog, which) -> showConnectScreen())
            .show();
    }

    @Override public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack();
        else showConnectScreen();
    }
}
